from valkit.core.scanner import ValkitScanner

s = ValkitScanner()

print('Testing scan...')
r = s.scan('INFY')
print(f'[OK] scan: {r.ticker}, concern={r.highest_concern}')
print(f'     Analyst brief: {r.analyst_brief[:80]}...')

print('\nTesting compare...')
c = s.compare('INFY', 'TCS')
print(f'[OK] compare: INFY vs TCS completed')

print('\n=== All MCP core tools validated successfully! ===')
